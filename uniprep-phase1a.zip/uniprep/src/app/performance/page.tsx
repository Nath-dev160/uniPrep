import { LineChart } from "lucide-react";

import { PlaceholderPage } from "@/components/layout/placeholder-page";

export default function PerformancePage() {
  return (
    <PlaceholderPage
      icon={LineChart}
      title="Performance"
      description="Track your accuracy, answering speed, and progress by course and topic."
      comingSoon="Performance tracking isn't connected yet"
    />
  );
}
