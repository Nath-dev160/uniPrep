import { BookOpen } from "lucide-react";

import { PlaceholderPage } from "@/components/layout/placeholder-page";

export default function CoursesPage() {
  return (
    <PlaceholderPage
      icon={BookOpen}
      title="Courses"
      description="Browse courses within your university, department, and academic level."
      comingSoon="The question bank and course catalogue aren't connected yet"
    />
  );
}
